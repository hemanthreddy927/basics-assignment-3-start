import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: [`
    .whitetext{
      color: white;
    }`]
})
export class AppComponent {

  SecretPassword="PUNA";
  displayPara=false
  clicks=[];
  i=1;
  
  onClickButton(){
    this.displayPara=!this.displayPara;
    this.clicks.push(this.i);
    this.i=this.i+1;
  }
  getBackgroundColor(){
    return this.i>=5?'blue':'white';
  }
}
